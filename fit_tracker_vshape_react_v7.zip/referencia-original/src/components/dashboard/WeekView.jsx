import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format, startOfWeek, addDays, isSameDay, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CheckCircle2, Circle } from "lucide-react";

export default function WeekView({ workouts, selectedDate, onDateSelect }) {
  const weekStart = startOfWeek(new Date(), { locale: ptBR });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  const getWorkoutsForDay = (day) => {
    return workouts.filter(w => isSameDay(parseISO(w.data), day));
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
        <CardTitle>Esta Semana</CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="grid grid-cols-7 gap-2">
          {weekDays.map((day, index) => {
            const dayWorkouts = getWorkoutsForDay(day);
            const isSelected = isSameDay(day, selectedDate);
            const isToday = isSameDay(day, new Date());
            
            return (
              <button
                key={index}
                onClick={() => onDateSelect(day)}
                className={`p-3 rounded-xl transition-all duration-200 ${
                  isSelected
                    ? 'bg-gradient-to-br from-purple-500 to-blue-500 text-white shadow-lg scale-105'
                    : 'bg-white hover:bg-gray-50'
                }`}
              >
                <div className="text-xs font-medium mb-1">
                  {format(day, 'EEE', { locale: ptBR })}
                </div>
                <div className={`text-xl font-bold mb-2 ${
                  isToday && !isSelected ? 'text-purple-600' : ''
                }`}>
                  {format(day, 'd')}
                </div>
                <div className="flex justify-center gap-1">
                  {dayWorkouts.slice(0, 3).map((w, i) => (
                    w.concluido ? (
                      <CheckCircle2 key={i} className={`w-3 h-3 ${isSelected ? 'text-white' : 'text-green-500'}`} />
                    ) : (
                      <Circle key={i} className={`w-3 h-3 ${isSelected ? 'text-white' : 'text-gray-400'}`} />
                    )
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}