import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format, parseISO, subWeeks } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CheckCircle2, Clock, Edit, Dumbbell, ChevronDown, ChevronUp, Play, RotateCcw } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import ExerciseProgress from "../workout/ExerciseProgress";

export default function RecentWorkouts({ workouts, exercises, isLoading }) {
  const [expandedWorkout, setExpandedWorkout] = React.useState(null);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: allWorkouts = [] } = useQuery({
    queryKey: ['allWorkouts'],
    queryFn: () => base44.entities.Workout.list('-data'),
    initialData: [],
  });

  const { data: allExercises = [] } = useQuery({
    queryKey: ['allExercises'],
    queryFn: () => base44.entities.Exercise.list(),
    initialData: [],
  });

  const uncompleteWorkoutMutation = useMutation({
    mutationFn: async (id) => {
      return await base44.entities.Workout.update(id, { concluido: false });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workouts'] });
    },
  });

  const getExercisesCount = (workoutId) => {
    return exercises.filter(e => e.workout_id === workoutId).length;
  };

  const getExercisesForWorkout = (workoutId) => {
    return exercises.filter(e => e.workout_id === workoutId).sort((a, b) => a.ordem - b.ordem);
  };

  const getPreviousExercise = (exerciseName, currentWorkoutDate) => {
    const oneWeekAgo = subWeeks(parseISO(currentWorkoutDate), 1);
    
    const previousWorkouts = allWorkouts
      .filter(w => parseISO(w.data) < parseISO(currentWorkoutDate) && parseISO(w.data) >= oneWeekAgo)
      .sort((a, b) => parseISO(b.data) - parseISO(a.data));

    for (const workout of previousWorkouts) {
      const exercise = allExercises.find(
        e => e.workout_id === workout.id && e.nome.toLowerCase() === exerciseName.toLowerCase()
      );
      if (exercise && exercise.carga_numerica) {
        return exercise;
      }
    }
    return null;
  };

  const diaSemanaPt = {
    segunda: "Segunda",
    terca: "Terça",
    quarta: "Quarta",
    quinta: "Quinta",
    sexta: "Sexta",
    sabado: "Sábado",
    domingo: "Domingo"
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
        <CardTitle>Treinos Recentes</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="p-4 border rounded-xl">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))}
          </div>
        ) : workouts.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Dumbbell className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>Nenhum treino cadastrado ainda.</p>
            <p className="text-sm mt-2">Comece criando seu primeiro treino!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {workouts.slice(0, 5).map((workout) => {
              const workoutExercises = getExercisesForWorkout(workout.id);
              const isExpanded = expandedWorkout === workout.id;

              return (
                <div
                  key={workout.id}
                  className="p-4 border border-gray-100 rounded-xl hover:shadow-md transition-all duration-200 bg-white"
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-1">{workout.titulo}</h3>
                      <div className="flex flex-wrap gap-2 text-sm text-gray-600">
                        <span>{format(parseISO(workout.data), "d 'de' MMM", { locale: ptBR })}</span>
                        {workout.dia_semana && (
                          <>
                            <span>•</span>
                            <span>{diaSemanaPt[workout.dia_semana]}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <Badge
                      variant={workout.concluido ? "default" : "outline"}
                      className={workout.concluido 
                        ? "bg-gradient-to-r from-green-500 to-emerald-500 border-none" 
                        : "border-gray-300"
                      }
                    >
                      {workout.concluido ? (
                        <>
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Concluído
                        </>
                      ) : (
                        <>
                          <Clock className="w-3 h-3 mr-1" />
                          Pendente
                        </>
                      )}
                    </Badge>
                  </div>

                  {workoutExercises.length > 0 && (
                    <div className="mb-3">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setExpandedWorkout(isExpanded ? null : workout.id)}
                        className="w-full justify-between text-gray-600 hover:text-purple-600 hover:bg-purple-50"
                      >
                        <span className="text-sm">
                          {getExercisesCount(workout.id)} exercícios
                        </span>
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </Button>

                      {isExpanded && (
                        <div className="mt-3 space-y-2 text-sm">
                          {workoutExercises.map((ex) => {
                            const prevExercise = getPreviousExercise(ex.nome, workout.data);
                            
                            return (
                              <div
                                key={ex.id}
                                className="flex items-center justify-between gap-2 p-2 bg-gray-50 rounded-lg"
                              >
                                <div className="flex items-center gap-2 flex-1 min-w-0">
                                  <div className="w-1.5 h-1.5 rounded-full bg-purple-500 flex-shrink-0" />
                                  <span className="font-medium truncate">{ex.nome}</span>
                                </div>
                                <div className="flex items-center gap-2 flex-shrink-0">
                                  <span className="text-gray-500">
                                    {ex.series}x{ex.repeticoes}
                                  </span>
                                  {ex.carga && (
                                    <span className="text-purple-600 font-medium">
                                      {ex.carga}
                                    </span>
                                  )}
                                  {ex.carga_numerica && prevExercise && (
                                    <ExerciseProgress
                                      currentCarga={ex.carga_numerica}
                                      previousCarga={prevExercise.carga_numerica}
                                    />
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}

                  <div className="flex gap-2 pt-2 border-t">
                    {workout.concluido ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => uncompleteWorkoutMutation.mutate(workout.id)}
                        className="flex-1 text-orange-600 hover:text-orange-700 hover:bg-orange-50 border-orange-200"
                      >
                        <RotateCcw className="w-4 h-4 mr-1" />
                        Refazer Treino
                      </Button>
                    ) : workoutExercises.length > 0 && (
                      <Button
                        size="sm"
                        onClick={() => navigate(`${createPageUrl("WorkoutExecution")}?id=${workout.id}`)}
                        className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
                      >
                        <Play className="w-4 h-4 mr-1" />
                        Executar
                      </Button>
                    )}
                    <Link to={`${createPageUrl("WorkoutForm")}?id=${workout.id}`} className={workout.concluido || !workoutExercises.length ? 'flex-1' : ''}>
                      <Button size="sm" variant="ghost" className={`text-purple-600 hover:text-purple-700 hover:bg-purple-50 ${workout.concluido || !workoutExercises.length ? 'w-full' : ''}`}>
                        <Edit className="w-4 h-4 mr-1" />
                        Editar
                      </Button>
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}