import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera, Image as ImageIcon, Calendar, Weight, TrendingUp, Dumbbell, MoreVertical, Trash2, Share2, Lock, Users, Globe, Edit2 } from "lucide-react";
import { format, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

import PhotoUpload from "../progress/PhotoUpload";
import SharePhoto from "../progress/SharePhoto";
import PhotoPrivacyEdit from "../progress/PhotoPrivacyEdit";

export default function ProgressFeed() {
  const queryClient = useQueryClient();
  const [showUpload, setShowUpload] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [editingPhotoId, setEditingPhotoId] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const user = await base44.auth.me();
      setCurrentUser(user);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: photos = [], isLoading } = useQuery({
    queryKey: ['progressPhotos'],
    queryFn: async () => {
      const photos = await base44.entities.ProgressPhoto.list('-data_foto');
      return photos;
    },
    initialData: [],
  });

  const deletePhotoMutation = useMutation({
    mutationFn: async (photoId) => {
      return await base44.entities.ProgressPhoto.delete(photoId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['progressPhotos'] });
    },
  });

  const handlePhotoUploaded = () => {
    setShowUpload(false);
    queryClient.invalidateQueries({ queryKey: ['progressPhotos'] });
  };

  const handleDelete = (photoId) => {
    if (confirm('Tem certeza que deseja excluir esta foto?')) {
      deletePhotoMutation.mutate(photoId);
    }
  };

  const handlePrivacyUpdated = () => {
    setEditingPhotoId(null);
    queryClient.invalidateQueries({ queryKey: ['progressPhotos'] });
  };

  const filteredPhotos = photos.filter(photo => {
    if (photo.created_by === currentUser?.email) {
      return true;
    }
    
    if (photo.privacidade === 'publico') {
      return true;
    }
    
    if (photo.privacidade === 'treinador' && currentUser?.tipo_usuario === 'profissional') {
      const photoOwner = photo.created_by;
      return true;
    }
    
    return false;
  });

  const getPrivacyIcon = (privacidade) => {
    switch (privacidade) {
      case 'privado':
        return <Lock className="w-4 h-4 text-gray-600" />;
      case 'treinador':
        return <Users className="w-4 h-4 text-purple-600" />;
      case 'publico':
        return <Globe className="w-4 h-4 text-green-600" />;
      default:
        return <Lock className="w-4 h-4 text-gray-600" />;
    }
  };

  const getPrivacyLabel = (privacidade) => {
    switch (privacidade) {
      case 'privado':
        return 'Privado';
      case 'treinador':
        return 'Treinador';
      case 'publico':
        return 'Público';
      default:
        return 'Privado';
    }
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-purple-600" />
            <CardTitle>Evolução Visual</CardTitle>
          </div>
          <Button
            onClick={() => setShowUpload(!showUpload)}
            size="sm"
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <Camera className="w-4 h-4 mr-2" />
            Adicionar Foto
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {showUpload && (
          <div className="mb-6">
            <PhotoUpload
              onPhotoUploaded={handlePhotoUploaded}
              onCancel={() => setShowUpload(false)}
            />
          </div>
        )}

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4" />
              <p className="text-gray-500">Carregando fotos...</p>
            </div>
          </div>
        ) : filteredPhotos.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <ImageIcon className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">
              Nenhuma foto ainda
            </h3>
            <p className="text-gray-500 text-sm">
              Registre sua evolução adicionando fotos
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {filteredPhotos.map((photo) => (
              <div key={photo.id}>
                {editingPhotoId === photo.id ? (
                  <PhotoPrivacyEdit
                    photo={photo}
                    onCancel={() => setEditingPhotoId(null)}
                    onUpdated={handlePrivacyUpdated}
                  />
                ) : (
                  <div className="border border-gray-200 rounded-xl overflow-hidden bg-white">
                    {/* Header */}
                    <div className="p-4 flex items-center justify-between border-b">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                          <Camera className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="font-semibold text-sm">
                            {photo.created_by === currentUser?.email ? 'Minha Evolução' : 'Evolução'}
                          </p>
                          <p className="text-xs text-gray-500">
                            {format(parseISO(photo.data_foto), "dd 'de' MMM 'às' HH:mm", { locale: ptBR })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="flex items-center gap-1">
                          {getPrivacyIcon(photo.privacidade)}
                          {getPrivacyLabel(photo.privacidade)}
                        </Badge>
                        {photo.created_by === currentUser?.email && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => setEditingPhotoId(photo.id)} className="cursor-pointer">
                                <Edit2 className="w-4 h-4 mr-2" />
                                Editar Privacidade
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleDelete(photo.id)} className="text-red-600 cursor-pointer">
                                <Trash2 className="w-4 h-4 mr-2" />
                                Excluir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </div>
                    </div>

                    {/* Image */}
                    <img
                      src={photo.image_url}
                      alt="Foto de evolução"
                      className="w-full h-96 object-cover"
                    />

                    {/* Actions */}
                    <div className="p-4 border-b">
                      <SharePhoto photo={photo} />
                    </div>

                    {/* Stats */}
                    {(photo.peso_na_data || photo.treinos_concluidos || photo.exercicios_executados) && (
                      <div className="p-4 border-b">
                        <div className="flex flex-wrap gap-4">
                          {photo.peso_na_data && (
                            <div className="flex items-center gap-2 text-sm">
                              <Weight className="w-4 h-4 text-gray-500" />
                              <span className="font-semibold">{photo.peso_na_data} kg</span>
                            </div>
                          )}
                          {photo.treinos_concluidos !== null && photo.treinos_concluidos !== undefined && (
                            <div className="flex items-center gap-2 text-sm">
                              <TrendingUp className="w-4 h-4 text-green-500" />
                              <span>{photo.treinos_concluidos} treinos</span>
                            </div>
                          )}
                          {photo.exercicios_executados !== null && photo.exercicios_executados !== undefined && (
                            <div className="flex items-center gap-2 text-sm">
                              <Dumbbell className="w-4 h-4 text-purple-500" />
                              <span>{photo.exercicios_executados} exercícios</span>
                            </div>
                          )}
                          {photo.frequencia_semanal !== null && photo.frequencia_semanal !== undefined && (
                            <div className="flex items-center gap-2 text-sm">
                              <Calendar className="w-4 h-4 text-blue-500" />
                              <span>{photo.frequencia_semanal} treinos/semana</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Caption */}
                    {photo.observacoes && (
                      <div className="p-4">
                        <p className="text-sm text-gray-700">{photo.observacoes}</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}