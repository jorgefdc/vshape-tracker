import React from 'react';
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  eachDayOfInterval, 
  isSameMonth,
  isSameDay,
  addMonths,
  subMonths,
  startOfWeek,
  endOfWeek,
  parseISO
} from "date-fns";
import { ptBR } from "date-fns/locale";

export default function MonthCalendar({ currentMonth, selectedDate, workouts, onMonthChange, onDateSelect }) {
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = startOfWeek(monthStart, { locale: ptBR });
  const calendarEnd = endOfWeek(monthEnd, { locale: ptBR });
  
  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd });
  const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

  const getWorkoutsForDay = (day) => {
    return workouts.filter(w => isSameDay(parseISO(w.data), day));
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold">
            {format(currentMonth, "MMMM 'de' yyyy", { locale: ptBR })}
          </h2>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => onMonthChange(subMonths(currentMonth, 1))}
              className="rounded-xl"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => onMonthChange(addMonths(currentMonth, 1))}
              className="rounded-xl"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div className="grid grid-cols-7 gap-2 mb-2">
          {weekDays.map((day) => (
            <div key={day} className="text-center text-sm font-semibold text-gray-600 py-2">
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-2">
          {days.map((day, index) => {
            const dayWorkouts = getWorkoutsForDay(day);
            const isSelected = isSameDay(day, selectedDate);
            const isToday = isSameDay(day, new Date());
            const isCurrentMonth = isSameMonth(day, currentMonth);
            
            return (
              <button
                key={index}
                onClick={() => onDateSelect(day)}
                className={`
                  relative p-3 rounded-xl transition-all duration-200 min-h-[80px] flex flex-col
                  ${!isCurrentMonth ? 'text-gray-300' : ''}
                  ${isSelected 
                    ? 'bg-gradient-to-br from-purple-500 to-blue-500 text-white shadow-lg scale-105' 
                    : 'bg-white hover:bg-gray-50'
                  }
                  ${isToday && !isSelected ? 'ring-2 ring-purple-500' : ''}
                `}
              >
                <span className={`text-sm font-semibold ${
                  isToday && !isSelected ? 'text-purple-600' : ''
                }`}>
                  {format(day, 'd')}
                </span>
                {dayWorkouts.length > 0 && (
                  <div className="mt-auto flex flex-col gap-0.5">
                    {dayWorkouts.slice(0, 2).map((w, i) => (
                      <div
                        key={i}
                        className={`h-1 rounded-full ${
                          isSelected 
                            ? 'bg-white' 
                            : w.concluido 
                              ? 'bg-green-500' 
                              : 'bg-purple-500'
                        }`}
                      />
                    ))}
                    {dayWorkouts.length > 2 && (
                      <span className={`text-xs ${isSelected ? 'text-white' : 'text-gray-500'}`}>
                        +{dayWorkouts.length - 2}
                      </span>
                    )}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}