import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format, parseISO, subWeeks } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CheckCircle2, Clock, Edit, Dumbbell, Play, RotateCcw, Trash2, Calendar as CalendarIcon } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import ExerciseProgress from "../workout/ExerciseProgress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function WorkoutsList({ selectedDate, workouts, exercises, isLoading }) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [moveDialogOpen, setMoveDialogOpen] = useState(false);
  const [selectedWorkout, setSelectedWorkout] = useState(null);
  const [newDate, setNewDate] = useState("");

  const { data: allWorkouts = [] } = useQuery({
    queryKey: ['allWorkouts'],
    queryFn: () => base44.entities.Workout.list('-data'),
    initialData: [],
  });

  const { data: allExercises = [] } = useQuery({
    queryKey: ['allExercises'],
    queryFn: () => base44.entities.Exercise.list(),
    initialData: [],
  });

  const deleteWorkoutMutation = useMutation({
    mutationFn: async (id) => {
      const workoutExercises = exercises.filter(e => e.workout_id === id);
      for (const ex of workoutExercises) {
        await base44.entities.Exercise.delete(ex.id);
      }
      return await base44.entities.Workout.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workouts'] });
      queryClient.invalidateQueries({ queryKey: ['exercises'] });
    },
  });

  const moveWorkoutMutation = useMutation({
    mutationFn: async ({ id, newDate }) => {
      return await base44.entities.Workout.update(id, { data: newDate });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workouts'] });
      setMoveDialogOpen(false);
      setSelectedWorkout(null);
    },
  });

  const toggleCompleteMutation = useMutation({
    mutationFn: async ({ id, concluido }) => {
      return await base44.entities.Workout.update(id, { concluido: !concluido });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workouts'] });
    },
  });

  const handleDeleteWorkout = (workout) => {
    if (confirm(`Tem certeza que deseja excluir "${workout.titulo}"?`)) {
      deleteWorkoutMutation.mutate(workout.id);
    }
  };

  const handleMoveWorkout = (workout) => {
    setSelectedWorkout(workout);
    setNewDate(workout.data);
    setMoveDialogOpen(true);
  };

  const confirmMove = () => {
    if (selectedWorkout && newDate) {
      moveWorkoutMutation.mutate({ id: selectedWorkout.id, newDate });
    }
  };

  const getExercisesForWorkout = (workoutId) => {
    return exercises.filter(e => e.workout_id === workoutId);
  };

  const getPreviousExercise = (exerciseName, currentWorkoutDate) => {
    const oneWeekAgo = subWeeks(parseISO(currentWorkoutDate), 1);
    
    const previousWorkouts = allWorkouts
      .filter(w => parseISO(w.data) < parseISO(currentWorkoutDate) && parseISO(w.data) >= oneWeekAgo)
      .sort((a, b) => parseISO(b.data) - parseISO(a.data));

    for (const workout of previousWorkouts) {
      const exercise = allExercises.find(
        e => e.workout_id === workout.id && e.nome.toLowerCase() === exerciseName.toLowerCase()
      );
      if (exercise && exercise.carga_numerica) {
        return exercise;
      }
    }
    return null;
  };

  return (
    <>
      <Card className="border-none shadow-lg sticky top-4">
        <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
          <CardTitle className="text-lg">
            {format(selectedDate, "d 'de' MMMM", { locale: ptBR })}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          {workouts.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Dumbbell className="w-10 h-10 mx-auto mb-3 text-gray-300" />
              <p className="text-sm">Nenhum treino neste dia</p>
              <Link to={createPageUrl("WorkoutForm")}>
                <Button size="sm" className="mt-4 bg-gradient-to-r from-purple-600 to-blue-600">
                  Adicionar Treino
                </Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {workouts.map((workout) => {
                const workoutExercises = getExercisesForWorkout(workout.id);
                
                return (
                  <div
                    key={workout.id}
                    className="p-4 border border-gray-100 rounded-xl bg-white space-y-3"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold">{workout.titulo}</h3>
                        <p className="text-sm text-gray-500 mt-1">
                          {workoutExercises.length} exercícios
                        </p>
                      </div>
                      <Badge
                        variant={workout.concluido ? "default" : "outline"}
                        className={workout.concluido 
                          ? "bg-gradient-to-r from-green-500 to-emerald-500 border-none" 
                          : "border-gray-300"
                        }
                      >
                        {workout.concluido ? (
                          <>
                            <CheckCircle2 className="w-3 h-3 mr-1" />
                            Feito
                          </>
                        ) : (
                          <>
                            <Clock className="w-3 h-3 mr-1" />
                            Pendente
                          </>
                        )}
                      </Badge>
                    </div>

                    {workoutExercises.length > 0 && (
                      <div className="space-y-2 text-xs">
                        {workoutExercises.slice(0, 3).map((ex) => {
                          const prevExercise = getPreviousExercise(ex.nome, workout.data);
                          
                          return (
                            <div key={ex.id} className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2 text-gray-600 flex-1 min-w-0">
                                <div className="w-1 h-1 rounded-full bg-purple-500 flex-shrink-0" />
                                <span className="truncate">{ex.nome}</span>
                                <span className="text-gray-400 flex-shrink-0">
                                  {ex.series}x{ex.repeticoes}
                                </span>
                                {ex.carga && (
                                  <span className="text-purple-600 font-medium flex-shrink-0">
                                    {ex.carga}
                                  </span>
                                )}
                              </div>
                              {ex.carga_numerica && prevExercise && (
                                <ExerciseProgress
                                  currentCarga={ex.carga_numerica}
                                  previousCarga={prevExercise.carga_numerica}
                                />
                              )}
                            </div>
                          );
                        })}
                        {workoutExercises.length > 3 && (
                          <p className="text-gray-400 ml-3">
                            +{workoutExercises.length - 3} exercícios
                          </p>
                        )}
                      </div>
                    )}

                    <div className="flex gap-2 pt-2 border-t">
                      {workout.concluido ? (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => toggleCompleteMutation.mutate(workout)}
                          className="flex-1 text-orange-600 hover:text-orange-700 hover:bg-orange-50 border-orange-200"
                        >
                          <RotateCcw className="w-4 h-4 mr-1" />
                          Refazer
                        </Button>
                      ) : workoutExercises.length > 0 && (
                        <Button
                          size="sm"
                          onClick={() => navigate(`${createPageUrl("WorkoutExecution")}?id=${workout.id}`)}
                          className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
                        >
                          <Play className="w-4 h-4 mr-1" />
                          Executar
                        </Button>
                      )}
                      <Link to={`${createPageUrl("WorkoutForm")}?id=${workout.id}`}>
                        <Button size="sm" variant="outline">
                          <Edit className="w-4 h-4" />
                        </Button>
                      </Link>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleMoveWorkout(workout)}
                      >
                        <CalendarIcon className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteWorkout(workout)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={moveDialogOpen} onOpenChange={setMoveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Mover Treino</DialogTitle>
            <DialogDescription>
              Escolha uma nova data para "{selectedWorkout?.titulo}"
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="newDate">Nova Data</Label>
            <Input
              id="newDate"
              type="date"
              value={newDate}
              onChange={(e) => setNewDate(e.target.value)}
              className="mt-2"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMoveDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={confirmMove} className="bg-gradient-to-r from-purple-600 to-blue-600">
              Mover Treino
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}